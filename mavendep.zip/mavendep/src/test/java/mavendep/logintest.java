package mavendep;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;


public class logintest {
	

	 static AppiumDriver<MobileElement> driver;
	 //static AndroidDriver<MobieElement> driver1;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
try {
	login();
} catch (MalformedURLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
	}
	
	public static void login() throws MalformedURLException {
	    DesiredCapabilities cap = new DesiredCapabilities();
	cap.setCapability("Device Name","hamzaemulator");
	cap.setCapability("uid","98895a454d5a4b5136");
	    cap.setCapability("platformName","Android");
	    cap.setCapability("platformVersion","9");
	    cap.setCapability("appPackage","de.sevenmind.android");
	    cap.setCapability("appActivity","de.sevenmind.android.MainActivity");
 AndroidDriver<AndroidElement> driver = new AndroidDriver<>(new URL("http://127.0.0.1:4723/wd/hub"), cap);

	    System.out.println("Application started");
	  //  WebDriverWait wait = new WebDriverWait(driver, 100);
//driver.findElement(By.xpath("*//[@text ='CONTINUE']")).click();
	    WebDriverWait logWait = new WebDriverWait(driver, 10);
	    logWait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(".//*[@text='CONTINUE']"))); 
	    driver.findElement(By.xpath(".//*[@text='CONTINUE']")).click();
	 //   logWait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(".//*[@text='LOG IN']")));
driver.findElement(By.xpath(".//*[@text='LOG IN']")).click();
logWait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(".//*[@text='EMAIL']")));
driver.findElement(By.xpath(".//*[@text='EMAIL']")).click();
 driver.findElement(By.xpath(".//*[@text='email address']")).sendKeys("khanhamza594@gmail.com");
driver.findElement(By.xpath(".//*[@)text='password']")).sendKeys("admin123");
	    
	    
	}
}
